package ddns

const (
	GOGADDY = iota
	GOOGLE
)

const (
	A    = "A"
	AAAA = "AAAA"
)

const (
	GODADDYAPIURL = "https://api.godaddy.com"
)
