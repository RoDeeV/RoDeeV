package sqlite

import (
	"testing"
)

func TestGetDb(t *testing.T) {
	//	fmt.Println(GetDb())
	//	db:=GetDb()
	//	d:=model.DDNSTypeDBModel{
	//		Name: "test",
	//		ApiHost: "http://www.google.com",
	//	}
	//	db.Create(&d)
}
