package common

const (
	SERVICENAME = "casaos"
	VERSION     = "0.4.4.3"
	BODY        = " "
	RANW_NAME   = "IceWhale-RemoteAccess"
)
