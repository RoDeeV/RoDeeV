package op

const (
	WORK     = "work"
	RootName = "root"
)
