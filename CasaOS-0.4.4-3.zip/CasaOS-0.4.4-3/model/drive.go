package model

type Drive struct {
	Name    string `json:"name"`
	Icon    string `json:"icon"`
	AuthUrl string `json:"auth_url"`
}
