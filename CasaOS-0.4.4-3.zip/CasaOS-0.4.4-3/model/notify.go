package model

type NotifyMssage struct {
	Type string `json:"type"`
	Data string `json:"data"`
}
