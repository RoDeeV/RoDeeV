package model

type CasaOSHeart struct {
	UuId string `json:"uuid"`
	Type string `json:"type"`
}
