package types

const (
	APPLICATION = iota
	MEDIA
	PICTURE
	MUSIC
	SEARCH
	UNKNOWN
)
