package types

const RELY_TYPE_MYSQL = iota
