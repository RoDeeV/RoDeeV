package drivers

import (
	_ "github.com/IceWhaleTech/CasaOS/drivers/dropbox"
	_ "github.com/IceWhaleTech/CasaOS/drivers/google_drive"
	_ "github.com/IceWhaleTech/CasaOS/drivers/onedrive"
)

// All do nothing,just for import
// same as _ import
func All() {

}
