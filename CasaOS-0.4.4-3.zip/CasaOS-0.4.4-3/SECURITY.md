# Security Policy

## Supported Versions

CasaOS is currently under active development. Support is limited before CasaOS reaches v1.0.

## Reporting a Vulnerability

If you see any vulnerabiility, email us at wiki@casaos.io
